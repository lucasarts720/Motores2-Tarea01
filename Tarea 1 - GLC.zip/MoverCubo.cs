using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoverCubo : MonoBehaviour

    /// Este Script va dentro de un GameObject, hace que cada vez que le das a "Play", el objeto se mueva a una ubicacion al azar

{
    // Start is called before the first frame update
    void Start()
    {
        move();
    }

    public void move()
    {
        gameObject.transform.position = new Vector3(Random.Range(-5, 5), Random.Range(-5, 5), Random.Range(-5, 5));
    }

    public void reset()
    {
        gameObject.transform.position = new Vector3(0, 0, 0);
    }
}