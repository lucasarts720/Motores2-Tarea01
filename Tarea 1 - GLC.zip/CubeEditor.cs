using UnityEngine;
using UnityEditor;

///  Este Script va dentro de la carpeta "Editor", para que sea ignorado por Github.
///  Hace aparecer dos botones en el Inspector, cuando se este viendo al GameObject que tenga el script "MoverCubo".
///  1) Hace mover el GameObject, usando su Metodo "move()"
///  2) Vuelve a poner el GameObject en la ubicacion (0,0,0) usando el metodo "reset()"

[CustomEditor(typeof(MoverCubo))]
public class CubeEditor : Editor
{
    public override void OnInspectorGUI()
    {
        base.OnInspectorGUI();

        MoverCubo cube = (MoverCubo)target;

        if (GUILayout.Button("Mover Cubo"))
        {
            cube.move();
        }

        if (GUILayout.Button("Reset"))
        {
            cube.reset();
        }
    }
}